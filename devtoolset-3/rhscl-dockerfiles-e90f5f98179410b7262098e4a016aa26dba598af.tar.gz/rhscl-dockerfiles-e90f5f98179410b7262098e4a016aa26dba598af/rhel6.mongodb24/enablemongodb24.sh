#!/bin/bash

source scl_source enable mongodb24
