Software Collection ruby193 Dockerfile
======================================

Build
-----

Building this Dockerfile requires a Red Hat Enterprise Linux 7 host
system with Software Collections entitlements available.

Run
---

docker run -t -i ruby193 /bin/bash -l
