#!/bin/bash

source scl_source enable rh-python34
