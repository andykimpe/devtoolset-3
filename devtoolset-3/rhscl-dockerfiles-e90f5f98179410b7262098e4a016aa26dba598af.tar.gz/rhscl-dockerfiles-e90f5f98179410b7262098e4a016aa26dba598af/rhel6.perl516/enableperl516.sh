#!/bin/bash

source scl_source enable perl516
