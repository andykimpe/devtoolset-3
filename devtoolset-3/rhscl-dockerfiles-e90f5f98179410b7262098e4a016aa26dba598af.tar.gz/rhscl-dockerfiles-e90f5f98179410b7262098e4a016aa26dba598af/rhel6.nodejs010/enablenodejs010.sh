#!/bin/bash

source scl_source enable nodejs010
