#!/bin/bash

source scl_source enable rh-passenger40 rh-ruby22
