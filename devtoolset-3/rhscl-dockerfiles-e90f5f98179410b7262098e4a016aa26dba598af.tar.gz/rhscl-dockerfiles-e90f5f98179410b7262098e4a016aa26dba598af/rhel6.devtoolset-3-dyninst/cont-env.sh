source /usr/share/cont-layer/common/functions.sh
cont_source_scripts common env
unset -f cont_source_scripts
