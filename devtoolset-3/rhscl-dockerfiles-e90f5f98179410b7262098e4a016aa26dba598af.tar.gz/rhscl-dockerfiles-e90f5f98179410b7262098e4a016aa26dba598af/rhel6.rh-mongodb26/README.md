Software Collection rh-mongodb26 Dockerfile
===========================================

Build
-----

Building this Dockerfile requires a Red Hat Enterprise Linux 7 host
system with Software Collections entitlements available.

Run
---

docker run -t -i rh-mongodb26 /bin/bash -l
